from fastapi import FastAPI, Request, Header
from starlette.responses import Response
import hmac, hashlib, base64, os, json
import datetime, pathlib

app = FastAPI()

# Read secret from env (default fallback only for dev)
SECRET = os.getenv("USANORTH_WEBHOOK_SECRET", "replace-me")

# Directory where we'll save incoming webhook payloads
LOG_DIR = pathlib.Path("/app/webhook_logs")
LOG_DIR.mkdir(parents=True, exist_ok=True)

def verify_signature(raw_body: bytes, header_value: str) -> bool:
    """
    Verify X-OneCall-Webhook-Signature: 'sha256=<base64>'
    """
    try:
        algo, b64sig = header_value.split("=", 1)
        if algo.lower() != "sha256":
            return False
        digest = hmac.new(SECRET.encode("utf-8"), raw_body, hashlib.sha256).digest()
        expected = base64.b64encode(digest).decode("ascii")
        return hmac.compare_digest(expected, b64sig)
    except Exception:
        return False

@app.get("/healthz")
def health():
    return {"ok": True}

@app.post("/webhooks/usanorth")
async def usanorth_webhook(
    request: Request,
    x_onecall_webhook_signature: str = Header(None),
):
    raw = await request.body()

    # Signature verification (required in production)
    if x_onecall_webhook_signature:
        if not verify_signature(raw, x_onecall_webhook_signature):
            print("❌ Invalid signature")
            return Response(status_code=401)

    # Parse JSON safely
    try:
        payload = json.loads(raw)
    except json.JSONDecodeError:
        print("⚠️ Invalid JSON body")
        return Response(status_code=400)

    # Extract info for logs
    msg = payload.get("message", {})
    ticket_number = msg.get("ticketNumber", "unknown")
    sequence = msg.get("sequenceNumber")
    station = msg.get("stationCode")
    notification_id = payload.get("webhookNotificationId")

    # Console summary log
    print("✅ Webhook received", {
        "webhookNotificationId": notification_id,
        "ticketNumber": ticket_number,
        "sequenceNumber": sequence,
        "stationCode": station
    })

    # Write full payload to JSON file
    try:
        timestamp = datetime.datetime.utcnow().strftime("%Y%m%dT%H%M%S%fZ")
        filename = f"{timestamp}_{ticket_number}.json"
        filepath = LOG_DIR / filename
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2)
        print(f"📁 Saved payload to {filepath}")
    except Exception as e:
        print(f"⚠️ Failed to write payload: {e}")

    # Always respond quickly (prevent retries)
    return Response(status_code=204)
